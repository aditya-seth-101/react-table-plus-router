import React from 'react'
import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
const RowDeleter = () => {
  let data= useLocation()
  return (
    <>
      <span>Are you sure you want to delete this row</span>
      <form >
        <button type='submit' value="Submit">Submit</button>
      </form>
    </>
  )
}

export default RowDeleter