import React from 'react'

const TableHome = () => {
  return (
    <div>TableHome</div>
  )
}

export default TableHome